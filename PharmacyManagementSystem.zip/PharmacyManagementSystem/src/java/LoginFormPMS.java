
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
//import javax.swing.JOptionPane;

@WebServlet("/LoginForm")

public class LoginFormPMS extends HttpServlet {

    static String email, pass;

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        try {
            PrintWriter pw = response.getWriter();

            email = request.getParameter("uemail");
            pass = request.getParameter("psw");

            Connection con;
            con = DataBaseConnection.connect();

            Statement stmt = con.createStatement();
            //ResultSet rs1 = stmt.executeQuery("Select role from login where email='" + email + "'");

            //rs1.next();
            //String role = rs1.getString(1);
            HttpSession session = request.getSession();
            ResultSet rs = stmt.executeQuery("select * from Patient where P_email='" + email + "' and P_password='" + pass + "';");
            String useremail = rs.getString(1);
            String userpassword = rs.getString(6);
            if (rs.next()) {

            if ((useremail.equals(email))&(userpassword.equals(pass))) {
                
                session.setAttribute("s_email", email);
                session.setAttribute("s_pass", pass);
                response.sendRedirect("PatientHome.jsp");
            } else {
                session.setAttribute("s_email", email);
                session.setAttribute("s_pass", pass);
                response.sendRedirect("login.jsp");
            }
            }else {
                pw.println("<script type=\"text/javascript\">");
                pw.println("alert('Status Updated Successfully...');");
                pw.println("location='login.jsp';");
                pw.println("</script>");
            //pw.println("Invalid details");

        }
        } catch (Exception e) {
        }

    }

}
